import random

my_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 16, 12, 8, 4, 0]
random_list = random.sample(range(1, 50), 10)

def print_5th_index():
    print("\n\nprinting the 5th index of my_list:")
    # Printing the 5th item in my_list
    print(my_list[4])

def print_list_in_reverse():
    print("\n reverse list is: ")
    # Printing my_list in reverse order
    print(my_list[::-1])

def double_list_values():
    print(f"\n\nmy_list is first {my_list}")
    # Doubling the values in my_list
    doubled_list = [x * 2 for x in my_list]
    print(f"\nafter doubling, my_list is now: {doubled_list}")

def print_highest_number_in_random_list():
    print("\n\nrandom_list contains: ")
    print(random_list)
    print("\nhighest number in list is: ")
    # Printing the highest number in random_list
    print(max(random_list))

def print_lowest_number_in_random_list():
    print("\n\nrandom_list contains: ")
    print(random_list)
    print("\nlowest number in list is: ")
    # Printing the lowest number in random_list
    print(min(random_list))

if __name__ == '__main__':
    print_5th_index()
    print_list_in_reverse()
    double_list_values()
    print_highest_number_in_random_list()
    print_lowest_number_in_random_list()
