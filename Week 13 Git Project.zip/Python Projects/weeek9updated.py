import random

# Provided dictionary
house_dict = {1: 4, 2: 2, 3: 2, 4: 3, 5: 1, 6: 2}
random_dict = {}  # Will be initialized later with random values

# Function to print the house with the most people
def print_the_house_with_the_most_people():
    house = max(house_dict, key=house_dict.get)
    people = house_dict[house]
    print(f"House {house} has the most people: {people}")

# Function to print the house with the least people
def print_the_house_with_the_least_people():
    house = min(house_dict, key=house_dict.get)
    people = house_dict[house]
    print(f"House {house} has the fewest people: {people}")

# Function to create and print the random house
def create_and_print_the_random_house():
    for x in range(1, random.randint(5, 10)):
        random_dict[x] = random.randint(1, 10)
    print("\n\nprinting the randomly generated dictionary of houses and people")
    for x in random_dict:
        print(f"House {x} has {random_dict[x]} people")

# Function to print total number of people living in random houses
def print_total_number_of_people_living_in_random_houses():
    total_people = sum(random_dict.values())
    print(f"\n\nTotal number of people living in randomly generated houses: {total_people}")

# Function to print average number of people living in random houses
def print_average_number_of_people_living_in_random_houses():
    if random_dict:
        average_people = sum(random_dict.values()) / len(random_dict)
        print(f"\n\nAverage number of people living in randomly generated houses: {average_people:.2f}")
    else:
        print("\n\nNo data available for average calculation.")

if __name__ == '__main__':
    print_the_house_with_the_most_people()
    print_the_house_with_the_least_people()
    create_and_print_the_random_house()
    print_total_number_of_people_living_in_random_houses()
    print_average_number_of_people_living_in_random_houses()