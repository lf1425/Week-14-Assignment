import requests
import json

# URL of the JSON data
url = 'https://data.cdc.gov/api/views/25m4-6qqq/rows.json?accessType=DOWNLOAD'

# Fetching the data from the URL
response = requests.get(url)
if response.status_code == 200:
    data = response.json()
else:
    print(f"Failed to retrieve data, status code: {response.status_code}")
    data = None

# If data fetching was successful, proceed with the analysis
if data:
    data_entries = data['data']

# Helper functions to filter and analyze the data
def filter_data(entries, conditions):
    """
    Filter data entries based on the given conditions.
    """
    filtered_entries = []
    for entry in entries:
        match = True
        for condition_key, condition_value in conditions.items():
            if condition_key == "Outcome (or Indicator)" and entry[8] != condition_value:
                match = False
                break
            if condition_key == "Year" and str(entry[-1]) != str(condition_value):
                match = False
                break
            if condition_key == "Group" and entry[10] != condition_value:
                match = False
                break
        if match:
            filtered_entries.append(entry)
    return filtered_entries

def extract_valid_percentages(entries):
    """
    Extract valid percentage values from the entries.
    """
    percentages = []
    for entry in entries:
        percentage = entry[11]
        ci = entry[12] if entry[12] else "0,0"
        ci_low, ci_high = map(float, ci.replace(" ", "").split(","))
        try:
            percentage_val = float(percentage)
            if 0 < percentage_val < 100 and ci_low <= percentage_val <= ci_high:
                percentages.append(percentage_val)
        except ValueError:
            continue
    return percentages

def find_highest_percentage_group(entries):
    """
    Find the group with the highest valid percentage value.
    """
    highest_percentage = 0
    highest_group = ""
    for entry in entries:
        group = entry[10]
        percentages = extract_valid_percentages([entry])
        if percentages:
            max_percentage = max(percentages)
            if max_percentage > highest_percentage:
                highest_percentage = max_percentage
                highest_group = group
    return highest_group, highest_percentage

# Questions Breakdown
# 1. Percentage of adults in the 18–34-year age range saw a doctor for a “Wellness Visit” in 2019 and 2020
wellness_visits_2019 = filter_data(data_entries, {"Outcome (or Indicator)": "Wellness visit", "Year": 2019, "Group": "18-34 years"})
wellness_visits_2020 = filter_data(data_entries, {"Outcome (or Indicator)": "Wellness visit", "Year": 2020, "Group": "18-34 years"})

percentages_2019 = extract_valid_percentages(wellness_visits_2019)
percentages_2020 = extract_valid_percentages(wellness_visits_2020)

avg_percentage_2019 = sum(percentages_2019) / len(percentages_2019) if percentages_2019 else 0
avg_percentage_2020 = sum(percentages_2020) / len(percentages_2020) if percentages_2020 else 0

# 2. Group with the highest percentage of “Obesity” in 2020
obesity_2020 = filter_data(data_entries, {"Outcome (or Indicator)": "Obesity", "Year": 2020})
highest_obesity_group, highest_obesity_percentage = find_highest_percentage_group(obesity_2020)

# 3. Groups with increased percentage of “Difficulty communicating” from 2019 to 2020
difficulty_communicating_2019 = filter_data(data_entries, {"Outcome (or Indicator)": "Difficulty communicating", "Year": 2019})
difficulty_communicating_2020 = filter_data(data_entries, {"Outcome (or Indicator)": "Difficulty communicating", "Year": 2020})

# Identify groups present in both years
groups_2019 = set(entry[10] for entry in difficulty_communicating_2019)
groups_2020 = set(entry[10] for entry in difficulty_communicating_2020)
common_groups = groups_2019.intersection(groups_2020)

# Calculate percentage change for common groups
increased_difficulty_groups = {}
for group in common_groups:
    group_entries_2019 = filter_data(difficulty_communicating_2019, {"Group": group})
    group_entries_2020 = filter_data(difficulty_communicating_2020, {"Group": group})
    percentages_2019 = extract_valid_percentages(group_entries_2019)
    percentages_2020 = extract_valid_percentages(group_entries_2020)
    avg_percentage_2019 = sum(percentages_2019) / len(percentages_2019) if percentages_2019 else 0
    avg_percentage_2020 = sum(percentages_2020) / len(percentages_2020) if percentages_2020 else 0
    if avg_percentage_2020 > avg_percentage_2019:
        increased_difficulty_groups[group] = (avg_percentage_2019, avg_percentage_2020)

avg_percentage_2019, avg_percentage_2020, highest_obesity_group, highest_obesity_percentage, increased_difficulty_groups

# Display the results
print(f"Percentage of adults in the 18–34-year age range who saw a doctor for a 'Wellness Visit' in 2019: {avg_percentage_2019:.2f}%")
print(f"Percentage of adults in the 18–34-year age range who saw a doctor for a 'Wellness Visit' in 2020: {avg_percentage_2020:.2f}%")

print(f"\nGroup of adults with the highest percentage of 'Obesity' in 2020: {highest_obesity_group} ({highest_obesity_percentage:.2f}%)")

print("\nGroups of adults with an increased percentage of 'Difficulty communicating' from 2019 to 2020:")
for group, percentages in increased_difficulty_groups.items():
    print(f"- {group}: {percentages[0]:.2f}% in 2019 to {percentages[1]:.2f}% in 2020")
