class CincinnatiSportsTeam:
    # Constructor
    def __init__(self, name, sport, stadium):
        self.name = name  # Team name
        self.sport = sport  # Type of sport (e.g., Baseball, Football, Soccer)
        self.stadium = stadium  # Home stadium

    # Team details
    def display_team_info(self):
        print(f"The {self.name} are a {self.sport} team, and their home stadium is {self.stadium}.")

# Instances for each Cincinnati sports team
reds = CincinnatiSportsTeam("Cincinnati Reds", "Baseball", "Great American Ball Park")
bengals = CincinnatiSportsTeam("Cincinnati Bengals", "Football", "Paul Brown Stadium")
fcCincinnati = CincinnatiSportsTeam("FC Cincinnati", "Soccer", "TQL Stadium")

# Use of the constructor and method for each team
reds.display_team_info()
bengals.display_team_info()
fcCincinnati.display_team_info()
